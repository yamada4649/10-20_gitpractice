module FavoritesHelper
end
